<x-guest-layout>
    <div class="flex-1 h-full max-w-4xl mx-auto overflow-hidden bg-white rounded-lg shadow-xl dark:bg-gray-800" >
        <div class="flex flex-col overflow-y-auto md:flex-row">
            <div class="h-32 md:h-auto md:w-1/2">
            <img
                aria-hidden="true"
                class="object-cover w-full h-full dark:hidden"
                src="{{asset('img/forgot-password-office.jpeg')}}"
                alt="Office"
            />
            <img
                aria-hidden="true"
                class="hidden object-cover w-full h-full dark:block"
                src="{{asset('img/forgot-password-office-dark.jpeg')}}"
                alt="Office"
            />
            </div>
            <div class="flex items-center justify-center p-6 sm:p-12 md:w-1/2">
            <div class="w-full">
                <h1
                class="mb-4 text-xl font-semibold text-gray-700 dark:text-gray-200"
                >
                Forgot password
                </h1>
                <form action="{{ route('password.email') }}" method="post">
                    @csrf
                    <label class="block text-sm">
                        <span class="text-gray-700 dark:text-gray-400">Email</span>
                        <input
                        class="form-control"
                        type="email" name="email" value="{{old('email')}}" required autofocus 

                        />
                    </label>
                     @error('email') <span class="text-red-600 text-sm pt-3">{{ $message }}</span> @enderror
                    <button type="submit"
                        class="btn-primary"
                    >
                        Recover password
                    </button>
                </form>
            </div>
            </div>
        </div>
    </div>
</x-guest-layout>