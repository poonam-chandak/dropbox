<x-guest-layout>
    <div class="flex flex-col overflow-y-auto md:flex-row">
        <div class="h-32 md:h-auto md:w-1/2">
        <img aria-hidden="true" class="object-cover w-full h-full dark:hidden"
            src="{{asset('/img/login-office.jpeg')}}" alt="Office" />
        <img aria-hidden="true"  class="hidden object-cover w-full h-full dark:block"
            src="{{asset('img/login-office-dark.jpeg')}}"
            alt="Office"
        />
        </div>
        <div class="flex items-center justify-center p-6 sm:p-12 md:w-1/2">
        <div class="w-full">
            <h1 class="mb-4 text-xl font-semibold text-gray-700 dark:text-gray-200">
                Login
            </h1>
         
            @include('layouts.flash-msg')
            <form action="{{ route('login') }}" method="post">
                @csrf
            
                <label class="block text-sm">
                    <span class="text-gray-700 dark:text-gray-400">Email</span>
                    <input
                    class="form-control" name="email" value="{{old('email')}}" required autofocus
                    placeholder="Jane Doe"
                    />
                    @error('email') <span class="text-red-600 text-sm pt-3">{{ $message }}</span> @enderror
                </label>
                <label class="block mt-4 text-sm" x-data="{show:false}">
                    <span class="text-gray-700 dark:text-gray-400">Password</span>
                    <div
                    class="relative text-gray-500 focus-within:text-purple-600 dark:focus-within:text-purple-400"
                    >
                    <input
                        class="form-control"
                        :type="show ? 'text' : 'password'"
                        type="password"  name="password" required autocomplete="current-password"
                    />
                    <div class="absolute inset-y-0 right-0 flex items-center mr-3  cursor-pointer"  @click="show = !show" >
                        <svg
                        class="w-5 h-5" :class="show ? 'hidden' : 'block'"
                        enable-background="new 0 0 96 96"  viewBox="0 0 96 96"  
                        >
                            <path d="M48,20c21.15,0,34.502,19.998,38.998,28C82.494,56.016,69.145,76,48,76C26.853,76,13.503,56.118,9.003,48.149  C13.5,40.101,26.853,20,48,20 M48,12C16,12,0,48.166,0,48.166S16,84,48,84s48-36,48-36S80,12,48,12L48,12z"/><path d="M48,40c4.411,0,8,3.589,8,8s-3.589,8-8,8s-8-3.589-8-8S43.589,40,48,40 M48,32c-8.836,0-16,7.164-16,16  c0,8.837,7.164,16,16,16c8.837,0,16-7.163,16-16C64,39.164,56.837,32,48,32L48,32z"/>
                        </svg>

                        <svg class="w-5 h-5" :class="show ? 'block' : 'hidden'" fill="none"  stroke="#000" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24">
                            <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" x2="23" y1="1" y2="23"/>

                        </svg>
                    </div>
                    </div>
                </label>
                <button class="btn-primary" type="submit" >
                    Log in
                </button>
            </form>

            <hr class="my-8" />
            <p class="mt-4">
                @if (Route::has('password.request'))
                <a
                    class="text-sm font-medium text-purple-600 dark:text-purple-400 hover:underline"
                    href="{{ route('password.request') }}"
                >
                    Forgot your password?
                </a>
                
                @endif
            </p>
            
        </div>
        </div>
    </div>
</x-guest-layout>