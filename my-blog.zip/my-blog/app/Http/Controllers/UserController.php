<?php

namespace App\Http\Controllers;

use Auth;
use Carbon\Carbon;
use App\Models\City;
use App\Models\Role;
use App\Models\User;
use App\Models\Staff;
use App\Models\State;
use App\Models\Department;
use App\Models\DeviceToken;
use Illuminate\Http\Request;
use App\Models\ForgetPassword;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Mail;

class UserController extends Controller
{
    public function index()
    {
       return view('welcome');
    }
  
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function upload_image(Request $request)
    {
      	dd($request);
	 $image = $request->file('file');

     $imageName = time() . '.' . $image->extension();

     $image->move(public_path('upload'), $imageName);

     return response()->json(['success' => $imageName]);	 
   
    }
	
	function fetch_image()
    {
     $images = \File::allFiles(public_path('upload'));
     $output = '<div class="row">';
     foreach($images as $image)
     {
      $output .= '<div class="col-md-2">
      <video width="320" height="240" controls>
      <source src="'.asset('upload/' . $image->getFilename()).'" class="img-thumbnail" width="150" height="150"/>
               </video> <button type="button" class="btn btn-link remove_image" id="'.$image->getFilename().'">Remove</button>
            </div>';
     }
     $output .= '</div>';
     echo $output;
    }

    function delete_image(Request $request)
    {
     if($request->get('name'))
     {
      \File::delete(public_path('upload/' . $request->get('name')));
     }
    } 
}
